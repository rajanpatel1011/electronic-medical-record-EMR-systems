<div id='cssmenu'>
<ul>
   <li class='active'><a href='dashboard.php'><span>Home</span></a></li>
<!--   <li class='last'><a href='#'><span>Register Patient</span></a>-->
   <li class='last'><a href='#'><span>Edit Patient</span></a>
   <li class='last'><a href='dashboard.php'><span>View Patient</span></a>
   <!--<li class='last'><a href='#'><span>Discharge Patient</span></a>-->
   <li class='has-sub'><a href='#'><span>Bill</span></a>
      <ul>
         <li><a href='treatment_bill.php'><span>Treatment bill</span></a></li>
         <li><a href='diagnosis_bill.php'><span>Diagnosis bill</span></a></li>
         <li><a href='#'><span>Medicine bill</span></a></li>
        <!-- <li><a href='#'><span>Generate bill</span></a></li>-->
      </ul>
   </li>
   <li class='has-sub'><a href='#'><span>Report</span></a>
      <ul>
         <li><a href='#'><span>Diagnosis Report</span></a></li>
         <li class='last'><a href='#'><span>Treatment Report</span></a></li>
         <!--<li class='last'><a href='#'><span>Generate Report</span></a></li>-->
		 </ul>
   </li>
   <li class='last'><a href='logout.php'><span>Logout</span></a></li>
</ul>
</div>
