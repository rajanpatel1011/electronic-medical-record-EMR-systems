<?php
error_reporting(0);
include("config.php");
?>
<form id="form1" name="form1" method="post" action="">
 &nbsp; <br /><label>Search by Name or Email:</label>
<input type="text" name="string" id="string" value="<?php echo stripcslashes($_REQUEST["string"]); ?>" />
</select>
<input type="submit" name="button" id="button" value="Filter" />
  </label>
  <a href="dashboard.php"> 
  reset</a>
</form>
<br /><br />
<table border="1" cellspacing="2" cellpadding="8">
  <tr>
        <td width="90" height="37" bgcolor="#CCCCCC"><strong><center>Patient id</center></strong></td>
    <td width="120" bgcolor="#CCCCCC"><strong><center>Name</center></strong></td>
    <td width="30" bgcolor="#CCCCCC"><strong><center>Sex</center></strong></td>
    <td width="80" bgcolor="#CCCCCC"><strong><center>category</center></strong></td>
    <td width="95" bgcolor="#CCCCCC"><strong><center>Admission Date</center></strong></td>
    <td width="95" bgcolor="#CCCCCC"><strong><center>Discharge date</center></strong></td>
    <td width="159" bgcolor="#CCCCCC"><strong><center>Address</center></strong></td>
    <td width="30" bgcolor="#CCCCCC"><strong><center>Age</center></strong></td>
    <td width="113" bgcolor="#CCCCCC"><strong><center>Email</center></strong></td>
    <td width="30" bgcolor="#CCCCCC"><strong><center>Edit</center></strong></td>
  </tr>
<?php
if ($_REQUEST["string"]<>'') {
	$search_string = " AND (name LIKE '%".mysql_real_escape_string($_REQUEST["string"])."%' OR email LIKE '%".mysql_real_escape_string($_REQUEST["string"])."%')";	
}

if ($_REQUEST["admission_date"]<>'' and $_REQUEST["discharge_date"]<>'') {
	$sql = "SELECT * FROM ".$SETTINGS["data_table"]." WHERE admission_date >= '".mysql_real_escape_string($_REQUEST["admission_date"])."' AND discharge_date <= '".mysql_real_escape_string($_REQUEST["discharge_date"])."'".$search_string;
}
else {
	$sql = "SELECT * FROM ".$SETTINGS["data_table"]." WHERE patient_id>0".$search_string;
}

$sql_result = mysql_query ($sql, $connection ) or die ('request "Could not execute SQL query" '.$sql);
if (mysql_num_rows($sql_result)>0) {
	while ($row = mysql_fetch_assoc($sql_result)) {
?>
  <tr>
    <td align="center" height="30px" bgcolor="#CCCCCC"><?php echo $row["patient_id"]; ?></td>
    <td><?php echo $row["name"]; ?></td>
    <td align="center"><?php echo $row["sex"]; ?></td>
    <td align="center"><?php echo $row["category"]; ?></td>
    <td align="center"><?php echo $row["admission_date"]; ?></td>
    <td align="center"><?php echo $row["discharge_date"]; ?></td>
    <td><?php echo $row["address"]; ?></td>
	<td align="center"><?php echo $row["age"]; ?></td>
    <td><?php echo $row["email"]; ?></td>
   <?php echo "<td><a href='patient_edit.php?patient_id=".$row['patient_id']."'>Edit</a></td>"; ?>
  </tr>
<?php
	}
} else {
?>
<tr><td colspan="2">No results found.</td>
<?php	
}
?>
</table>