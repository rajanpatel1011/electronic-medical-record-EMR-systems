<?php
error_reporting(0);
session_start();
$message="";
if(count($_POST)>0) {
$conn = mysql_connect("localhost","root","");
mysql_select_db("acharyadb",$conn);
$result = mysql_query("SELECT * FROM employee WHERE email='" . $_POST["user_name"] . "' and password = '". $_POST["password"]."'");
$row  = mysql_fetch_array($result);
if(is_array($row)) {
$_SESSION["user_id"] = $row[emp_id];
$_SESSION["user_name"] = $row[name];
$_SESSION["category"] = $row[category];
$_POST["category"] = $row[category];
} else {
$message = "Invalid Username or Password!";
}
}
if(isset($_SESSION["user_id"])) {
		
		if($_POST["category"] == "d")
		{
			header("Location:dashboard.php");
		}
		else{
			$message = "Invalid Username or Password!";	
		}
		if($_POST["category"] == "n")
		{
			header("Location:dashboard.php");
		}
		else{
			$message = "Invalid Username or Password!";	
		}
		if($_POST["category"] == "p")
		{
			header("Location:dashboard.php");
		}
		else{
			$message = "Invalid Username or Password!";	
		}
		if($_POST["category"] == "r")
		{
			header("Location:dashboard.php");
		}
		else{
			$message = "Invalid Username or Password!";	
		}
		if($_POST["category"] == "a")
		{
			header("Location:dashboard.php");
		}
		else{
			$message = "Invalid Username or Password!";	
		}
}
?>
<html>
<head>
<title>User Login</title>
<link rel="stylesheet" type="text/css" href="login_styles.css" />
</head>
<body>
<form name="frmUser" method="post" action="">
<div class="message"><?php if($message!="") { echo $message; } ?></div>
<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
<tr class="tableheader">
<td align="center" colspan="2">Enter Login Details</td>
</tr>
<tr class="tablerow">
<td align="right">Username</td>
<td><input type="text" name="user_name"></td>
</tr>
<tr class="tablerow">
<td align="right">Password</td>
<td><input type="password" name="password"></td>
</tr>
<tr class="tableheader">
<td align="center" colspan="2"><input type="submit" name="submit" value="Submit"></td>
</tr>
</table>
</form>
</body></html>